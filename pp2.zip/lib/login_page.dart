// login_page.dart - NEO-BRUTALISM FINAL EDITION
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'splash.dart';

const String baseUrl = "http://alfa-store-officials.alfamarket2.my.id:3583";

// ═══════════════════════════════════════════════════════════════════
//  NEO-BRUTALISM THEME
// ═══════════════════════════════════════════════════════════════════
class _C {
  static const bg          = Color(0xFFFFFFFF);
  static const white       = Color(0xFFFFFFFF);
  static const yellow      = Color(0xFFFFE600);
  static const yellowSoft  = Color(0xFFFFF9CC);
  static const black       = Color(0xFF000000);
  static const textPrimary = Color(0xFF000000);
  static const textSec     = Color(0xFF333333);
  static const textMuted   = Color(0xFF777777);
  static const error       = Color(0xFFFF1744);
  static const warning     = Color(0xFFFFAB40);
  static const success     = Color(0xFF00C853);
  static const cyan        = Color(0xFF00E5FF);
}

class _S {
  static List<BoxShadow> get sm => const [
    BoxShadow(color: _C.black, offset: Offset(2, 2), blurRadius: 0),
  ];
  static List<BoxShadow> get md => const [
    BoxShadow(color: _C.black, offset: Offset(4, 4), blurRadius: 0),
  ];
  static List<BoxShadow> get lg => const [
    BoxShadow(color: _C.black, offset: Offset(6, 6), blurRadius: 0),
  ];
}

// ═══════════════════════════════════════════════════════════════════
//  LOGIN PAGE
// ═══════════════════════════════════════════════════════════════════
class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage>
    with TickerProviderStateMixin {
  final userController = TextEditingController();
  final passController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  bool isLoading = false;
  bool _obscurePassword = true;
  String? androidId;

  late AnimationController _controller;
  late Animation<double> _fadeAnim;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    )..forward();
    _fadeAnim = CurvedAnimation(
        parent: _controller, curve: Curves.easeOutCubic);

    initLogin();
  }

  @override
  void dispose() {
    _controller.dispose();
    userController.dispose();
    passController.dispose();
    super.dispose();
  }

  Future<void> initLogin() async {
    androidId = await _getAndroidId();
    final prefs = await SharedPreferences.getInstance();
    final savedUser = prefs.getString("username");
    final savedPass = prefs.getString("password");
    final savedKey = prefs.getString("key");

    if (savedUser != null && savedPass != null && savedKey != null) {
      final uri = Uri.parse(
          "$baseUrl/myInfo?username=$savedUser&password=$savedPass&androidId=$androidId&key=$savedKey");
      try {
        final res = await http.get(uri);
        final data = jsonDecode(res.body);
        if (data['valid'] == true && mounted) {
          Navigator.pushReplacement(context, _fadeRoute(SplashScreen(
            username: savedUser,
            password: savedPass,
            role: (data['role'] ?? '').toString(),
            sessionKey: data['key'],
            expiredDate: data['expiredDate'],
            listBug: (data['listBug'] as List? ?? [])
                .map((e) => Map<String, dynamic>.from(e as Map))
                .toList(),
            listDoos: (data['listDDoS'] as List? ?? [])
                .map((e) => Map<String, dynamic>.from(e as Map))
                .toList(),
            news: (data['news'] as List? ?? [])
                .map((e) => Map<String, dynamic>.from(e as Map))
                .toList(),
          )));
        }
      } catch (_) {}
    }
  }

  Future<String> _getAndroidId() async {
    final deviceInfo = DeviceInfoPlugin();
    final android = await deviceInfo.androidInfo;
    return android.id ?? "unknown_device";
  }

  PageRouteBuilder _fadeRoute(Widget page) => PageRouteBuilder(
        transitionDuration: const Duration(milliseconds: 500),
        pageBuilder: (_, __, ___) => page,
        transitionsBuilder: (_, anim, __, child) => FadeTransition(
          opacity: anim.drive(
            Tween(begin: 0.0, end: 1.0)
                .chain(CurveTween(curve: Curves.easeOutCubic)),
          ),
          child: child,
        ),
      );

  Future<void> login() async {
    if (!_formKey.currentState!.validate()) return;
    final username = userController.text.trim();
    final password = passController.text.trim();
    setState(() => isLoading = true);

    try {
      final validate = await http.post(
        Uri.parse("$baseUrl/validate"),
        body: {
          "username": username,
          "password": password,
          "androidId": androidId ?? "unknown_device"
        },
      );
      final validData = jsonDecode(validate.body);

      if (validData['expired'] == true) {
        _showPopup(
          title: "ACCESS EXPIRED",
          message: "Your access has expired.\nPlease renew it.",
          color: _C.warning,
          icon: Icons.warning_amber_rounded,
          showContact: true,
        );
      } else if (validData['valid'] != true) {
        _showPopup(
          title: "LOGIN FAILED",
          message: "Invalid username or password.",
          color: _C.error,
          icon: Icons.error_rounded,
        );
      } else {
        final prefs = await SharedPreferences.getInstance();
        prefs.setString("username", username);
        prefs.setString("password", password);
        prefs.setString("key", validData['key']);
        if (mounted) {
          Navigator.pushReplacement(context, _fadeRoute(SplashScreen(
            username: username,
            password: password,
            role: (validData['role'] ?? '').toString(),
            sessionKey: validData['key'],
            expiredDate: validData['expiredDate'],
            listBug: (validData['listBug'] as List? ?? [])
                .map((e) => Map<String, dynamic>.from(e as Map))
                .toList(),
            listDoos: (validData['listDDoS'] as List? ?? [])
                .map((e) => Map<String, dynamic>.from(e as Map))
                .toList(),
            news: (validData['news'] as List? ?? [])
                .map((e) => Map<String, dynamic>.from(e as Map))
                .toList(),
          )));
        }
      }
    } catch (_) {
      _showPopup(
        title: "CONNECTION ERROR",
        message:
            "Failed to connect to the server.\nPlease check your internet connection.",
        color: _C.error,
        icon: Icons.wifi_off_rounded,
      );
    }

    if (mounted) setState(() => isLoading = false);
  }

  void _buyAccount() async {
    HapticFeedback.lightImpact();
    await launchUrl(
      Uri.parse("https://t.me/alfinjawa"),
      mode: LaunchMode.externalApplication,
    );
  }

  // ─── POPUP ─────────────────────────────────────────────────
  void _showPopup({
    required String title,
    required String message,
    Color color = _C.black,
    IconData icon = Icons.info_rounded,
    bool showContact = false,
  }) {
    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 24),
        child: Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: _C.white,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _C.black, width: 3),
            boxShadow: _S.md,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: color,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: _C.black, width: 2.5),
                      boxShadow: _S.sm,
                    ),
                    child: Icon(icon, color: _C.white, size: 20),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      title,
                      style: const TextStyle(
                        color: _C.black,
                        fontSize: 15,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.2,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              Text(
                message,
                style: const TextStyle(
                  color: _C.textSec,
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  height: 1.4,
                ),
              ),
              const SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  if (showContact) ...[
                    _SmallBtn(
                      label: 'CONTACT',
                      bgColor: _C.yellow,
                      onTap: () async {
                        await launchUrl(
                          Uri.parse("https://t.me/alfinjawa"),
                          mode: LaunchMode.externalApplication,
                        );
                      },
                    ),
                    const SizedBox(width: 8),
                  ],
                  _SmallBtn(
                    label: 'CLOSE',
                    bgColor: _C.black,
                    textColor: _C.yellow,
                    onTap: () => Navigator.pop(context),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      body: Stack(
        children: [
          // Dot pattern background
          Positioned.fill(
            child: CustomPaint(painter: _DotPatternPainter()),
          ),

          SafeArea(
            child: FadeTransition(
              opacity: _fadeAnim,
              child: Center(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 20, vertical: 24),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      // ═══ HEADER CARD (logo + empty space) ═══
                      _buildHeaderCard(),

                      const SizedBox(height: 16),

                      // ═══ FORM CARD (SIGN IN + fields + buttons) ═══
                      _buildFormCard(),

                      const SizedBox(height: 18),

                      // ═══ FOOTER (ID + Contact) ═══
                      _buildFooter(),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════
  //  HEADER CARD (Logo kotak kecil + empty space)
  // ═══════════════════════════════════════════════════════════════
  Widget _buildHeaderCard() {
    return TweenAnimationBuilder<double>(
      duration: const Duration(milliseconds: 500),
      tween: Tween(begin: 0.0, end: 1.0),
      curve: Curves.easeOutCubic,
      builder: (_, v, child) => Opacity(
        opacity: v,
        child: Transform.translate(
          offset: Offset(0, 20 * (1 - v)),
          child: child,
        ),
      ),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: _C.white,
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: _C.black, width: 3),
          boxShadow: _S.md,
        ),
        child: Row(
          children: [
            // Logo kotak kuning
            Container(
              width: 72,
              height: 72,
              decoration: BoxDecoration(
                color: _C.yellow,
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: _C.black, width: 3),
                boxShadow: _S.sm,
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(15),
                child: Image.asset(
                  'assets/images/logo.png',
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => const Icon(
                    Icons.bolt_rounded,
                    color: _C.black,
                    size: 36,
                  ),
                ),
              ),
            ),
            const SizedBox(width: 14),
            // Text
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text(
                    'ZIROTRAS V8 RAT',
                    style: TextStyle(
                      fontFamily: 'Genetic',
                      fontSize: 22,
                      fontWeight: FontWeight.w900,
                      color: _C.black,
                      letterSpacing: 1.5,
                      height: 1.0,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Container(
                    height: 2.5,
                    width: 60,
                    decoration: BoxDecoration(
                      color: _C.black,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      color: _C.black,
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: const Text(
                      'SADAP JARAK JAUH',
                      style: TextStyle(
                        color: _C.yellow,
                        fontSize: 8,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.5,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════
  //  FORM CARD (SIGN IN + fields + 2 buttons)
  // ═══════════════════════════════════════════════════════════════
  Widget _buildFormCard() {
    return TweenAnimationBuilder<double>(
      duration: const Duration(milliseconds: 700),
      tween: Tween(begin: 0.9, end: 1.0),
      curve: Curves.easeOutCubic,
      builder: (_, v, child) =>
          Transform.scale(scale: v, child: child),
      child: Container(
        padding: const EdgeInsets.all(22),
        decoration: BoxDecoration(
          color: _C.white,
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: _C.black, width: 3),
          boxShadow: _S.lg,
        ),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // ─── SIGN IN HEADER ─────────────────────
              Row(
                children: [
                  // Black bar
                  Container(
                    width: 6,
                    height: 28,
                    decoration: BoxDecoration(
                      color: _C.black,
                      borderRadius: BorderRadius.circular(3),
                    ),
                  ),
                  const SizedBox(width: 10),
                  const Text(
                    'SIGN IN',
                    style: TextStyle(
                      fontFamily: 'Genetic',
                      color: _C.black,
                      fontSize: 20,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 2,
                      height: 1.0,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 6),
              Padding(
                padding: const EdgeInsets.only(left: 16),
                child: Text(
                  'Enter your credentials to continue',
                  style: TextStyle(
                    color: _C.textMuted.withOpacity(0.85),
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                    fontStyle: FontStyle.italic,
                  ),
                ),
              ),
              const SizedBox(height: 20),

              // ─── USERNAME FIELD ─────────────────────
              _buildTextField(
                controller: userController,
                hint: 'Username',
                icon: Icons.person_outline_rounded,
              ),
              const SizedBox(height: 14),

              // ─── PASSWORD FIELD ─────────────────────
              _buildTextField(
                controller: passController,
                hint: 'Password',
                icon: Icons.lock_outline_rounded,
                obscureText: _obscurePassword,
                isPassword: true,
              ),
              const SizedBox(height: 22),

              // ─── 2 BUTTONS (BUY + LOGIN) ────────────
              Row(
                children: [
                  // BUY ACCOUNT button
                  Expanded(
                    child: _DualButton(
                      label: 'BUY ACCOUNT',
                      bgColor: _C.yellow,
                      textColor: _C.black,
                      onTap: _buyAccount,
                      loading: false,
                      icon: Icons.shopping_bag_rounded,
                    ),
                  ),
                  const SizedBox(width: 12),
                  // LOGIN button
                  Expanded(
                    child: _DualButton(
                      label: 'LOGIN',
                      bgColor: _C.black,
                      textColor: _C.yellow,
                      onTap: isLoading ? null : login,
                      loading: isLoading,
                      icon: Icons.arrow_forward_rounded,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════
  //  FOOTER
  // ═══════════════════════════════════════════════════════════════
  Widget _buildFooter() {
    return TweenAnimationBuilder<double>(
      duration: const Duration(milliseconds: 800),
      tween: Tween(begin: 0.0, end: 1.0),
      curve: Curves.easeOutCubic,
      builder: (_, v, child) => Opacity(
        opacity: v,
        child: Transform.translate(
          offset: Offset(0, 15 * (1 - v)),
          child: child,
        ),
      ),
      child: Column(
        children: [
          // ID chip
          Container(
            padding: const EdgeInsets.symmetric(
                horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: _C.white,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: _C.black, width: 2),
              boxShadow: _S.sm,
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  padding: const EdgeInsets.all(4),
                  decoration: BoxDecoration(
                    color: _C.yellow,
                    borderRadius: BorderRadius.circular(4),
                    border: Border.all(color: _C.black, width: 1.5),
                  ),
                  child: const Icon(Icons.fingerprint_rounded,
                      color: _C.black, size: 11),
                ),
                const SizedBox(width: 8),
                Text(
                  "ID: ${androidId ?? 'Scanning...'}",
                  style: const TextStyle(
                    color: _C.black,
                    fontSize: 9,
                    fontFamily: 'monospace',
                    fontWeight: FontWeight.w800,
                    letterSpacing: 0.5,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),

          // Contact admin
          GestureDetector(
            onTap: () async {
              HapticFeedback.lightImpact();
              await launchUrl(
                Uri.parse("https://t.me/alfinjawa"),
                mode: LaunchMode.externalApplication,
              );
            },
            child: Container(
              padding: const EdgeInsets.symmetric(
                  horizontal: 16, vertical: 10),
              decoration: BoxDecoration(
                color: _C.yellow,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: _C.black, width: 2.5),
                boxShadow: _S.sm,
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    padding: const EdgeInsets.all(4),
                    decoration: BoxDecoration(
                      color: _C.black,
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: const Icon(
                      Icons.support_agent_rounded,
                      color: _C.yellow,
                      size: 14,
                    ),
                  ),
                  const SizedBox(width: 8),
                  const Text(
                    'No account? Contact admin',
                    style: TextStyle(
                      color: _C.black,
                      fontSize: 11,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 0.3,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════
  //  TEXT FIELD (hint di dalam, no label di atas)
  // ═══════════════════════════════════════════════════════════════
  Widget _buildTextField({
    required TextEditingController controller,
    required String hint,
    required IconData icon,
    bool obscureText = false,
    bool isPassword = false,
  }) {
    return TextFormField(
      controller: controller,
      obscureText: obscureText,
      style: const TextStyle(
        color: _C.black,
        fontSize: 14,
        fontWeight: FontWeight.w700,
      ),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: const TextStyle(
          color: _C.textMuted,
          fontSize: 13,
          fontWeight: FontWeight.w600,
        ),
        prefixIcon: Icon(icon, color: _C.black, size: 20),
        suffixIcon: isPassword
            ? IconButton(
                icon: Icon(
                  _obscurePassword
                      ? Icons.visibility_outlined
                      : Icons.visibility_off_outlined,
                  color: _C.black,
                  size: 20,
                ),
                onPressed: () {
                  HapticFeedback.lightImpact();
                  setState(
                      () => _obscurePassword = !_obscurePassword);
                },
              )
            : null,
        filled: true,
        fillColor: _C.yellowSoft,
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 18, vertical: 18),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide:
              const BorderSide(color: _C.black, width: 3),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide:
              const BorderSide(color: _C.black, width: 3),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide:
              const BorderSide(color: _C.black, width: 4),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide:
              const BorderSide(color: _C.error, width: 3),
        ),
        focusedErrorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide:
              const BorderSide(color: _C.error, width: 4),
        ),
        errorStyle: const TextStyle(
          color: _C.error,
          fontSize: 11,
          fontWeight: FontWeight.w800,
        ),
      ),
      validator: (v) =>
          (v == null || v.isEmpty) ? "Please enter $hint" : null,
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  DUAL BUTTON (BUY ACCOUNT + LOGIN)
// ═══════════════════════════════════════════════════════════════════
class _DualButton extends StatefulWidget {
  final String label;
  final Color bgColor;
  final Color textColor;
  final VoidCallback? onTap;
  final bool loading;
  final IconData? icon;

  const _DualButton({
    required this.label,
    required this.bgColor,
    required this.textColor,
    required this.onTap,
    this.loading = false,
    this.icon,
  });

  @override
  State<_DualButton> createState() => _DualButtonState();
}

class _DualButtonState extends State<_DualButton> {
  bool _isPressed = false;

  void _handleTap() {
    if (widget.loading || widget.onTap == null) return;
    HapticFeedback.mediumImpact();
    setState(() => _isPressed = true);
    Future.delayed(const Duration(milliseconds: 150), () {
      if (mounted) setState(() => _isPressed = false);
      widget.onTap?.call();
    });
  }

  @override
  Widget build(BuildContext context) {
    final disabled = widget.onTap == null;

    return GestureDetector(
      onTap: _handleTap,
      child: AnimatedScale(
        duration: const Duration(milliseconds: 120),
        scale: _isPressed ? 0.95 : 1.0,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 150),
          height: 54,
          decoration: BoxDecoration(
            color: disabled ? _C.textMuted : widget.bgColor,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: _C.black, width: 3),
            boxShadow: _isPressed || disabled ? [] : _S.sm,
          ),
          child: Center(
            child: widget.loading
                ? SizedBox(
                    width: 22,
                    height: 22,
                    child: CircularProgressIndicator(
                      strokeWidth: 3,
                      color: widget.textColor,
                    ),
                  )
                : Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Flexible(
                        child: Text(
                          widget.label,
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w900,
                            color: widget.textColor,
                            letterSpacing: 1.5,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      if (widget.icon != null) ...[
                        const SizedBox(width: 6),
                        Container(
                          padding: const EdgeInsets.all(3),
                          decoration: BoxDecoration(
                            color: widget.textColor,
                            borderRadius: BorderRadius.circular(5),
                          ),
                          child: Icon(
                            widget.icon,
                            color: widget.bgColor,
                            size: 12,
                          ),
                        ),
                      ],
                    ],
                  ),
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  SMALL BUTTON (dialog)
// ═══════════════════════════════════════════════════════════════════
class _SmallBtn extends StatefulWidget {
  final String label;
  final Color bgColor;
  final Color textColor;
  final VoidCallback onTap;

  const _SmallBtn({
    required this.label,
    required this.bgColor,
    this.textColor = _C.black,
    required this.onTap,
  });

  @override
  State<_SmallBtn> createState() => _SmallBtnState();
}

class _SmallBtnState extends State<_SmallBtn> {
  bool _pressed = false;
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) => setState(() => _pressed = false),
      onTapCancel: () => setState(() => _pressed = false),
      onTap: () {
        HapticFeedback.lightImpact();
        widget.onTap();
      },
      child: AnimatedScale(
        duration: const Duration(milliseconds: 90),
        scale: _pressed ? 0.95 : 1.0,
        child: Container(
          padding:
              const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
          decoration: BoxDecoration(
            color: widget.bgColor,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: _C.black, width: 2.5),
            boxShadow: _S.sm,
          ),
          child: Text(
            widget.label,
            style: TextStyle(
              color: widget.textColor,
              fontWeight: FontWeight.w900,
              fontSize: 11,
              letterSpacing: 1,
            ),
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  DOT PATTERN BACKGROUND
// ═══════════════════════════════════════════════════════════════════
class _DotPatternPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = _C.yellow.withOpacity(0.35)
      ..style = PaintingStyle.fill;

    const spacing = 24.0;
    const dotRadius = 1.5;

    for (double x = 0; x < size.width; x += spacing) {
      for (double y = 0; y < size.height; y += spacing) {
        canvas.drawCircle(Offset(x, y), dotRadius, paint);
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}