// landing_page.dart - FINAL NEO-BRUTALISM EDITION
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import 'login_page.dart';

// ═══════════════════════════════════════════════════════════════════
//  NEO-BRUTALISM THEME
// ═══════════════════════════════════════════════════════════════════
class AppColors {
  static const bg        = Color(0xFFFFFFFF);
  static const yellow    = Color(0xFFFFE600);
  static const yellowSoft = Color(0xFFFFF9CC);
  static const cyan      = Color(0xFF00E5FF);
  static const black     = Color(0xFF000000);
  static const white     = Color(0xFFFFFFFF);
  static const gray      = Color(0xFF888888);
  static const textMuted = Color(0xFF555555);
  static const success   = Color(0xFF00C853);
  static const blue      = Color(0xFF2196F3);
  static const orange    = Color(0xFFFF9800);
  static const error     = Color(0xFFFF1744);
}

class _S {
  static List<BoxShadow> get sm => const [
    BoxShadow(color: AppColors.black, offset: Offset(2, 2), blurRadius: 0),
  ];
  static List<BoxShadow> get md => const [
    BoxShadow(color: AppColors.black, offset: Offset(4, 4), blurRadius: 0),
  ];
  static List<BoxShadow> get lg => const [
    BoxShadow(color: AppColors.black, offset: Offset(6, 6), blurRadius: 0),
  ];
}

// ═══════════════════════════════════════════════════════════════════
//  LANDING PAGE
// ═══════════════════════════════════════════════════════════════════
class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage>
    with TickerProviderStateMixin {
  late AnimationController _entryCtrl;
  late AnimationController _buttonCtrl;
  late AnimationController _pulseCtrl;
  late Animation<double> _entryAnim;
  late Animation<double> _buttonAnim;
  late Animation<double> _pulseAnim;

  @override
  void initState() {
    super.initState();

    _entryCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1400));
    _entryAnim = CurvedAnimation(
        parent: _entryCtrl, curve: Curves.easeOutCubic);

    _buttonCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 800));
    _buttonAnim = CurvedAnimation(
        parent: _buttonCtrl, curve: Curves.easeOutBack);

    _pulseCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 2000))
      ..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.4, end: 1.0).animate(
      CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut),
    );

    _entryCtrl.forward();
    Future.delayed(const Duration(milliseconds: 900), () {
      if (mounted) _buttonCtrl.forward();
    });
  }

  @override
  void dispose() {
    _entryCtrl.dispose();
    _buttonCtrl.dispose();
    _pulseCtrl.dispose();
    super.dispose();
  }

  // Helper: staggered animation
  Widget _staggered({
    required double delay,
    required Widget child,
  }) {
    return AnimatedBuilder(
      animation: _entryCtrl,
      builder: (_, __) {
        final start = (delay / 1.4).clamp(0.0, 1.0);
        final raw =
            ((_entryCtrl.value - start) / (1 - start)).clamp(0.0, 1.0);
        final t = Curves.easeOutCubic.transform(raw);
        return Opacity(
          opacity: t,
          child: Transform.translate(
            offset: Offset(0, (1 - t) * 30),
            child: child,
          ),
        );
      },
      child: child,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      body: Stack(
        children: [
          // ═══ BACKGROUND PATTERN ═══
          Positioned.fill(
            child: CustomPaint(painter: _PatternPainter()),
          ),

          // ═══ DECO SHAPES ═══
          Positioned(
            top: -80,
            right: -80,
            child: _staggered(
              delay: 0,
              child: Container(
                width: 220,
                height: 220,
                decoration: BoxDecoration(
                  color: AppColors.yellow,
                  borderRadius: BorderRadius.circular(60),
                  border: Border.all(color: AppColors.black, width: 4),
                ),
              ),
            ),
          ),
          Positioned(
            bottom: -60,
            left: -60,
            child: _staggered(
              delay: 100,
              child: Container(
                width: 180,
                height: 180,
                decoration: BoxDecoration(
                  color: AppColors.cyan,
                  borderRadius: BorderRadius.circular(50),
                  border: Border.all(color: AppColors.black, width: 4),
                ),
              ),
            ),
          ),

          SafeArea(
            child: FadeTransition(
              opacity: _entryAnim,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24),
                child: Column(
                  children: [
                    // ═══ TOP BAR ═══
                    _staggered(
                      delay: 0,
                      child: Padding(
                        padding: const EdgeInsets.only(top: 14),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            // Left: brand mini
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 10, vertical: 5),
                              decoration: BoxDecoration(
                                color: AppColors.white,
                                borderRadius: BorderRadius.circular(20),
                                border: Border.all(
                                    color: AppColors.black, width: 2),
                                boxShadow: _S.sm,
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Container(
                                    width: 6,
                                    height: 6,
                                    decoration: const BoxDecoration(
                                      color: AppColors.black,
                                      shape: BoxShape.circle,
                                    ),
                                  ),
                                  const SizedBox(width: 6),
                                  const Text(
                                    'ZIROTRAS V8',
                                    style: TextStyle(
                                      fontFamily: 'Genetic',
                                      color: AppColors.black,
                                      fontSize: 11,
                                      fontWeight: FontWeight.w900,
                                      letterSpacing: 1.5,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            // Right: version chip
                            _VersionChip(),
                          ],
                        ),
                      ),
                    ),

                    const Spacer(flex: 3),

                    // ═══ HERO LOGO ═══
                    _staggered(delay: 100, child: _HeroLogo()),

                    const SizedBox(height: 28),

                    // ═══ BRAND ═══
                    _staggered(
                      delay: 300,
                      child: _buildBrandRow(),
                    ),

                    const SizedBox(height: 12),

                    // ═══ TAGLINE ═══
                    _staggered(
                      delay: 400,
                      child: _buildTagline(),
                    ),

                    const Spacer(flex: 2),

                    // ═══ INFO CARD ═══
                    _staggered(
                      delay: 500,
                      child: _buildInfoCard(),
                    ),

                    const SizedBox(height: 14),

                    // ═══ STATS ROW ═══
                    _staggered(
                      delay: 600,
                      child: _buildStatsRow(),
                    ),

                    const SizedBox(height: 32),

                    // ═══ MAIN BUTTON ═══
                    FadeTransition(
                      opacity: _buttonAnim,
                      child: SlideTransition(
                        position: Tween<Offset>(
                          begin: const Offset(0, 0.4),
                          end: Offset.zero,
                        ).animate(CurvedAnimation(
                          parent: _buttonCtrl,
                          curve: Curves.easeOutCubic,
                        )),
                        child: _BigButton(
                          text: 'GET STARTED',
                          icon: Icons.arrow_forward_rounded,
                          onTap: () {
                            HapticFeedback.mediumImpact();
                            Navigator.pushNamed(context, '/login');
                          },
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),

                    // ═══ LOGIN LINK ═══
                    FadeTransition(
                      opacity: _buttonAnim,
                      child: _buildLoginLink(),
                    ),

                    const Spacer(flex: 1),

                    // ═══ FOOTER ═══
                    _staggered(
                      delay: 800,
                      child: _buildFooter(),
                    ),
                    const SizedBox(height: 18),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── BRAND ROW (ZIROTRAS V8 RAT + divider) ────────────────────
  Widget _buildBrandRow() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        // Left bar
        Container(
          width: 40,
          height: 4,
          decoration: BoxDecoration(
            color: AppColors.black,
            borderRadius: BorderRadius.circular(2),
          ),
        ),
        const SizedBox(width: 12),
        // Brand
        const Text(
          'ZIROTRAS V8 RAT',
          style: TextStyle(
            fontFamily: 'Genetic',
            color: AppColors.black,
            fontSize: 38,
            fontWeight: FontWeight.w900,
            letterSpacing: 3,
            height: 1.0,
          ),
        ),
        const SizedBox(width: 12),
        // Right bar
        Container(
          width: 40,
          height: 4,
          decoration: BoxDecoration(
            color: AppColors.black,
            borderRadius: BorderRadius.circular(2),
          ),
        ),
      ],
    );
  }

  // ─── TAGLINE ───────────────────────────────────────────
  Widget _buildTagline() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 7),
      decoration: BoxDecoration(
        color: AppColors.yellow,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppColors.black, width: 2.5),
        boxShadow: _S.sm,
      ),
      child: const Text(
        'APK SADAP JARAK JAUH',
        style: TextStyle(
          color: AppColors.black,
          fontSize: 10,
          fontWeight: FontWeight.w900,
          letterSpacing: 2.5,
        ),
      ),
    );
  }

  // ─── INFO CARD ─────────────────────────────────────────
  Widget _buildInfoCard() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.black, width: 3),
        boxShadow: _S.md,
      ),
      child: Row(
        children: [
          // Icon
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: AppColors.yellow,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: AppColors.black, width: 2),
            ),
            child: const Icon(Icons.shield_rounded,
                color: AppColors.black, size: 22),
          ),
          const SizedBox(width: 12),
          // Text
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  'REMOTE ADMIN TOOL',
                  style: TextStyle(
                    color: AppColors.black,
                    fontSize: 11,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.5,
                  ),
                ),
                SizedBox(height: 4),
                Text(
                  'Advanced features & fast performance',
                  style: TextStyle(
                    color: AppColors.textMuted,
                    fontSize: 10,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
          // Arrow
          Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: AppColors.black,
              borderRadius: BorderRadius.circular(8),
            ),
            child: const Icon(Icons.arrow_forward_rounded,
                color: AppColors.yellow, size: 14),
          ),
        ],
      ),
    );
  }

  // ─── STATS ROW ─────────────────────────────────────────
  Widget _buildStatsRow() {
    return Row(
      children: const [
        Expanded(
          child: _StatMiniCard(
            icon: Icons.bolt_rounded,
            label: 'LIVE',
            color: AppColors.success,
          ),
        ),
        SizedBox(width: 8),
        Expanded(
          child: _StatMiniCard(
            icon: Icons.lock_rounded,
            label: 'SECURE',
            color: AppColors.blue,
          ),
        ),
        SizedBox(width: 8),
        Expanded(
          child: _StatMiniCard(
            icon: Icons.speed_rounded,
            label: 'FAST',
            color: AppColors.orange,
          ),
        ),
      ],
    );
  }

  // ─── LOGIN LINK ────────────────────────────────────────
  Widget _buildLoginLink() {
    return GestureDetector(
      onTap: () {
        HapticFeedback.lightImpact();
        Navigator.pushNamed(context, '/login');
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: AppColors.white,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: AppColors.black, width: 2.5),
          boxShadow: _S.sm,
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'Already have an account?',
              style: TextStyle(
                color: AppColors.black,
                fontSize: 11,
                fontWeight: FontWeight.w700,
              ),
            ),
            const SizedBox(width: 8),
            Container(
              padding: const EdgeInsets.symmetric(
                  horizontal: 8, vertical: 3),
              decoration: BoxDecoration(
                color: AppColors.black,
                borderRadius: BorderRadius.circular(6),
              ),
              child: const Text(
                'LOGIN',
                style: TextStyle(
                  color: AppColors.yellow,
                  fontSize: 10,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── FOOTER ────────────────────────────────────────────
  Widget _buildFooter() {
    return Column(
      children: [
        // Divider
        Container(
          height: 2,
          decoration: BoxDecoration(
            color: AppColors.black,
            borderRadius: BorderRadius.circular(1),
          ),
        ),
        const SizedBox(height: 14),
        // Copyright chip
        Container(
          padding: const EdgeInsets.symmetric(
              horizontal: 14, vertical: 6),
          decoration: BoxDecoration(
            color: AppColors.white,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: AppColors.black, width: 2),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.copyright_rounded,
                  color: AppColors.black, size: 12),
              const SizedBox(width: 5),
              const Text(
                '2026 — ZIROTRAS V8 RAT',
                style: TextStyle(
                  color: AppColors.black,
                  fontSize: 10,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.5,
                ),
              ),
              const SizedBox(width: 8),
              Container(
                width: 4,
                height: 4,
                decoration: const BoxDecoration(
                  color: AppColors.success,
                  shape: BoxShape.circle,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  HERO LOGO (double ring + rotate)
// ═══════════════════════════════════════════════════════════════════
class _HeroLogo extends StatefulWidget {
  @override
  State<_HeroLogo> createState() => _HeroLogoState();
}

class _HeroLogoState extends State<_HeroLogo>
    with TickerProviderStateMixin {
  late AnimationController _rotateCtrl;
  late AnimationController _pulseCtrl;
  late AnimationController _orbitCtrl;
  late Animation<double> _rotate;
  late Animation<double> _pulse;
  late Animation<double> _orbit;

  @override
  void initState() {
    super.initState();
    // Rotate logonya sendiri (halus)
    _rotateCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 6))
      ..repeat(reverse: true);
    _rotate = Tween<double>(begin: -0.015, end: 0.015).animate(
      CurvedAnimation(parent: _rotateCtrl, curve: Curves.easeInOut),
    );

    // Pulse ring
    _pulseCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1800))
      ..repeat(reverse: true);
    _pulse = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut),
    );

    // Orbit dot
    _orbitCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 4))
      ..repeat();
    _orbit = Tween<double>(begin: 0.0, end: 1.0).animate(_orbitCtrl);
  }

  @override
  void dispose() {
    _rotateCtrl.dispose();
    _pulseCtrl.dispose();
    _orbitCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    const double logoSize = 130;
    const double ringSize = 170;

    return AnimatedBuilder(
      animation: Listenable.merge([_rotate, _pulse, _orbit]),
      builder: (_, child) {
        return SizedBox(
          width: ringSize + 40,
          height: ringSize + 40,
          child: Stack(
            alignment: Alignment.center,
            children: [
              // ─── Pulse ring kuning ───
              Container(
                width: ringSize + (_pulse.value * 30),
                height: ringSize + (_pulse.value * 30),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: AppColors.yellow
                        .withOpacity(1.0 - _pulse.value),
                    width: 3,
                  ),
                ),
              ),

              // ─── Cyan ring (static) ───
              Container(
                width: ringSize,
                height: ringSize,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: AppColors.black,
                    width: 4,
                  ),
                ),
              ),

              // ─── Orbit dot ───
              Transform.rotate(
                angle: _orbit.value * 2 * math.pi,
                child: SizedBox(
                  width: ringSize,
                  height: ringSize,
                  child: Align(
                    alignment: Alignment.topCenter,
                    child: Container(
                      width: 14,
                      height: 14,
                      decoration: BoxDecoration(
                        color: AppColors.cyan,
                        shape: BoxShape.circle,
                        border: Border.all(
                            color: AppColors.black, width: 2.5),
                      ),
                    ),
                  ),
                ),
              ),

              // ─── Logo box (rotate halus) ───
              Transform.rotate(
                angle: _rotate.value,
                child: child,
              ),
            ],
          ),
        );
      },
      child: Container(
        width: logoSize,
        height: logoSize,
        decoration: BoxDecoration(
          color: AppColors.yellow,
          borderRadius: BorderRadius.circular(28),
          border: Border.all(color: AppColors.black, width: 4),
          boxShadow: _S.lg,
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(24),
          child: Image.asset(
            'assets/images/logo.png',
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => const Icon(
              Icons.bolt_rounded,
              color: AppColors.black,
              size: 60,
            ),
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  VERSION CHIP
// ═══════════════════════════════════════════════════════════════════
class _VersionChip extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: AppColors.black,
        borderRadius: BorderRadius.circular(20),
        boxShadow: _S.sm,
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 6,
            height: 6,
            decoration: const BoxDecoration(
              color: AppColors.success,
              shape: BoxShape.circle,
            ),
          ),
          const SizedBox(width: 6),
          const Text(
            'v1.0  •  STABLE',
            style: TextStyle(
              color: AppColors.yellow,
              fontSize: 9,
              fontWeight: FontWeight.w900,
              letterSpacing: 1,
            ),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  STAT MINI CARD
// ═══════════════════════════════════════════════════════════════════
class _StatMiniCard extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;

  const _StatMiniCard({
    required this.icon,
    required this.label,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12),
      decoration: BoxDecoration(
        color: AppColors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.black, width: 2.5),
        boxShadow: _S.sm,
      ),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(7),
            decoration: BoxDecoration(
              color: color,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: AppColors.black, width: 2),
            ),
            child: Icon(icon, color: AppColors.white, size: 15),
          ),
          const SizedBox(height: 7),
          Text(
            label,
            style: const TextStyle(
              color: AppColors.black,
              fontSize: 9,
              fontWeight: FontWeight.w900,
              letterSpacing: 1.2,
            ),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  BIG BUTTON (Neo-brutalism + double shadow)
// ═══════════════════════════════════════════════════════════════════
class _BigButton extends StatefulWidget {
  final String text;
  final IconData icon;
  final VoidCallback onTap;

  const _BigButton({
    required this.text,
    required this.icon,
    required this.onTap,
  });

  @override
  State<_BigButton> createState() => _BigButtonState();
}

class _BigButtonState extends State<_BigButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) => setState(() => _pressed = false),
      onTapCancel: () => setState(() => _pressed = false),
      onTap: () {
        HapticFeedback.mediumImpact();
        widget.onTap();
      },
      child: AnimatedScale(
        duration: const Duration(milliseconds: 90),
        scale: _pressed ? 0.97 : 1.0,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 90),
          padding: const EdgeInsets.symmetric(vertical: 18),
          decoration: BoxDecoration(
            color: AppColors.black,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppColors.black, width: 3),
            boxShadow: _pressed
                ? []
                : const [
                    BoxShadow(
                      color: AppColors.yellow,
                      offset: Offset(5, 5),
                      blurRadius: 0,
                    ),
                    BoxShadow(
                      color: AppColors.black,
                      offset: Offset(5, 5),
                      blurRadius: 0,
                    ),
                  ],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                widget.text,
                style: const TextStyle(
                  color: AppColors.yellow,
                  fontSize: 14,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 3,
                ),
              ),
              const SizedBox(width: 10),
              Container(
                padding: const EdgeInsets.all(4),
                decoration: BoxDecoration(
                  color: AppColors.yellow,
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Icon(widget.icon,
                    color: AppColors.black, size: 16),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  PATTERN PAINTER (dot + garis diagonal)
// ═══════════════════════════════════════════════════════════════════
class _PatternPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    // Dot pattern
    final dotPaint = Paint()
      ..color = AppColors.yellow.withOpacity(0.35)
      ..style = PaintingStyle.fill;

    const spacing = 24.0;
    const dotRadius = 1.5;

    for (double x = 0; x < size.width; x += spacing) {
      for (double y = 0; y < size.height; y += spacing) {
        canvas.drawCircle(Offset(x, y), dotRadius, dotPaint);
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}