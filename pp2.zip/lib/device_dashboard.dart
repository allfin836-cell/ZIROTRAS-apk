// device_dashboard.dart - NEO-BRUTALISM EDITION
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:async';
import 'control_panel.dart';

const _kBase = 'http://panel.pterodactyl.cloud:4569';

// ═══════════════════════════════════════════════════════════════════
//  NEO-BRUTALISM THEME
// ═══════════════════════════════════════════════════════════════════
class DashboardTheme {
  static const bg       = Color(0xFFFFFFFF);
  static const surface  = Color(0xFFFFFFFF);
  static const surface2 = Color(0xFFFFF9CC); // kuning pudar
  static const surface3 = Color(0xFFFFE600); // kuning terang
  static const yellow   = Color(0xFFFFE600);
  static const black    = Color(0xFF000000);
  static const white    = Color(0xFFFFFFFF);
  static const textPrimary   = Color(0xFF000000);
  static const textSecondary = Color(0xFF333333);
  static const textMuted     = Color(0xFF777777);
  static const success = Color(0xFF00C853);
  static const warning = Color(0xFFFFAB40);
  static const error   = Color(0xFFFF1744);
}

class ShadowUtils {
  static List<BoxShadow> get sm => const [
    BoxShadow(color: DashboardTheme.black, offset: Offset(2, 2), blurRadius: 0),
  ];
  static List<BoxShadow> get md => const [
    BoxShadow(color: DashboardTheme.black, offset: Offset(4, 4), blurRadius: 0),
  ];
  static List<BoxShadow> get lg => const [
    BoxShadow(color: DashboardTheme.black, offset: Offset(6, 6), blurRadius: 0),
  ];
}

// ═══════════════════════════════════════════════════════════════════
//  BRUTAL CARD WRAPPER
// ═══════════════════════════════════════════════════════════════════
class _BrutalCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry? padding;
  final double radius;
  final Color? bgColor;
  final Color borderColor;
  final double borderWidth;
  final bool shadow;
  final VoidCallback? onTap;

  const _BrutalCard({
    required this.child,
    this.padding,
    this.radius = 16,
    this.bgColor,
    this.borderColor = DashboardTheme.black,
    this.borderWidth = 2.5,
    this.shadow = true,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    Widget box = Container(
      padding: padding ?? const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: bgColor ?? DashboardTheme.white,
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(color: borderColor, width: borderWidth),
        boxShadow: shadow ? ShadowUtils.md : null,
      ),
      child: child,
    );

    if (onTap != null) return _PressCard(onTap: onTap!, child: box);
    return box;
  }
}

class _PressCard extends StatefulWidget {
  final Widget child;
  final VoidCallback onTap;
  const _PressCard({required this.child, required this.onTap});
  @override
  State<_PressCard> createState() => _PressCardState();
}

class _PressCardState extends State<_PressCard> {
  bool _pressed = false;
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) => setState(() => _pressed = false),
      onTapCancel: () => setState(() => _pressed = false),
      onTap: () {
        HapticFeedback.lightImpact();
        widget.onTap();
      },
      child: AnimatedScale(
        duration: const Duration(milliseconds: 90),
        scale: _pressed ? 0.97 : 1.0,
        child: widget.child,
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  DEVICE LIST PAGE
// ═══════════════════════════════════════════════════════════════════
class _DeviceListPage extends StatelessWidget {
  final List<dynamic> devices;
  final String role;

  const _DeviceListPage({
    required this.devices,
    required this.role,
  });

  @override
  Widget build(BuildContext context) {
    final activeCount = devices.where((d) => d['online'] == true).length;

    return Column(
      children: [
        // Stats bar
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
          child: _BrutalCard(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            bgColor: DashboardTheme.white,
            child: Row(
              children: [
                _StatChip(
                  label: 'ONLINE',
                  value: '$activeCount',
                  color: DashboardTheme.success,
                ),
                const SizedBox(width: 8),
                _StatChip(
                  label: 'OFFLINE',
                  value: '${devices.length - activeCount}',
                  color: DashboardTheme.error,
                ),
                const Spacer(),
                _StatChip(
                  label: 'TOTAL',
                  value: '${devices.length}',
                  color: DashboardTheme.black,
                ),
              ],
            ),
          ),
        ),

        // Device List
        Expanded(
          child: devices.isEmpty
              ? const _EmptyDeviceWidget()
              : RefreshIndicator(
                  onRefresh: () async {},
                  color: DashboardTheme.black,
                  backgroundColor: DashboardTheme.yellow,
                  child: ListView.builder(
                    padding: const EdgeInsets.fromLTRB(16, 12, 16, 100),
                    physics: const AlwaysScrollableScrollPhysics(),
                    itemCount: devices.length,
                    itemBuilder: (ctx, i) {
                      final d = devices[i];
                      final isOnline = d['online'] == true;
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 12),
                        child: _DeviceCard(
                          device: d,
                          isOnline: isOnline,
                          role: role,
                        ),
                      );
                    },
                  ),
                ),
        ),
      ],
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  STAT CHIP
// ═══════════════════════════════════════════════════════════════════
class _StatChip extends StatelessWidget {
  final String label;
  final String value;
  final Color color;

  const _StatChip({
    required this.label,
    required this.value,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: color.withOpacity(0.15),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: DashboardTheme.black, width: 2),
      ),
      child: Row(
        children: [
          Container(
            width: 7,
            height: 7,
            decoration: BoxDecoration(
              color: color,
              shape: BoxShape.circle,
              border: Border.all(color: DashboardTheme.black, width: 1),
            ),
          ),
          const SizedBox(width: 6),
          Text(
            label,
            style: const TextStyle(
              color: DashboardTheme.black,
              fontSize: 9,
              fontWeight: FontWeight.w900,
              letterSpacing: 1,
            ),
          ),
          const SizedBox(width: 4),
          Text(
            value,
            style: const TextStyle(
              color: DashboardTheme.black,
              fontSize: 14,
              fontWeight: FontWeight.w900,
            ),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  DEVICE CARD
// ═══════════════════════════════════════════════════════════════════
class _DeviceCard extends StatelessWidget {
  final dynamic device;
  final bool isOnline;
  final String role;

  const _DeviceCard({
    required this.device,
    required this.isOnline,
    required this.role,
  });

  @override
  Widget build(BuildContext context) {
    final statusColor =
        isOnline ? DashboardTheme.success : DashboardTheme.error;

    return _BrutalCard(
      padding: const EdgeInsets.all(12),
      radius: 16,
      bgColor: isOnline ? DashboardTheme.yellow : DashboardTheme.white,
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) =>
              ControlCenterPage(targetDevice: device, role: role),
        ),
      ),
      child: Row(
        children: [
          // Icon device
          Container(
            padding: const EdgeInsets.all(11),
            decoration: BoxDecoration(
              color: DashboardTheme.white,
              borderRadius: BorderRadius.circular(12),
              border:
                  Border.all(color: DashboardTheme.black, width: 2.5),
              boxShadow: ShadowUtils.sm,
            ),
            child: Icon(
              Icons.phone_android_rounded,
              color: isOnline
                  ? DashboardTheme.black
                  : DashboardTheme.textMuted,
              size: 22,
            ),
          ),
          const SizedBox(width: 12),
          // Info device
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  device['model'] ?? 'Unknown Device',
                  style: const TextStyle(
                    color: DashboardTheme.black,
                    fontSize: 13,
                    fontWeight: FontWeight.w900,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 2),
                Text(
                  device['id'] ?? 'ID: ---',
                  style: const TextStyle(
                    color: DashboardTheme.textSecondary,
                    fontSize: 10,
                    fontWeight: FontWeight.w600,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 6),
                Row(
                  children: [
                    const Icon(
                      Icons.battery_charging_full_rounded,
                      color: DashboardTheme.black,
                      size: 13,
                    ),
                    const SizedBox(width: 4),
                    Text(
                      '${device['battery'] ?? '?'}%',
                      style: const TextStyle(
                        color: DashboardTheme.black,
                        fontSize: 11,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    if (!isOnline && device['lastSeen'] != null) ...[
                      const SizedBox(width: 10),
                      Text(
                        _formatLastSeen(device['lastSeen']),
                        style: const TextStyle(
                          color: DashboardTheme.textMuted,
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          // Status + arrow
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: statusColor,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                      color: DashboardTheme.black, width: 2),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 5,
                      height: 5,
                      decoration: const BoxDecoration(
                        color: DashboardTheme.white,
                        shape: BoxShape.circle,
                      ),
                    ),
                    const SizedBox(width: 4),
                    Text(
                      isOnline ? 'ON' : 'OFF',
                      style: const TextStyle(
                        color: DashboardTheme.white,
                        fontSize: 9,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 0.5,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 8),
              const Icon(
                Icons.arrow_forward_ios_rounded,
                color: DashboardTheme.black,
                size: 13,
              ),
            ],
          ),
        ],
      ),
    );
  }

  String _formatLastSeen(String? lastSeenStr) {
    if (lastSeenStr == null) return 'Never';
    try {
      final lastSeen = DateTime.parse(lastSeenStr);
      final diff = DateTime.now().difference(lastSeen);
      if (diff.inSeconds < 60) return '${diff.inSeconds}s ago';
      if (diff.inMinutes < 60) return '${diff.inMinutes}m ago';
      if (diff.inHours < 24) return '${diff.inHours}h ago';
      return '${diff.inDays}d ago';
    } catch (_) {
      return 'Never';
    }
  }
}

// ═══════════════════════════════════════════════════════════════════
//  EMPTY STATE
// ═══════════════════════════════════════════════════════════════════
class _EmptyDeviceWidget extends StatelessWidget {
  const _EmptyDeviceWidget();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: DashboardTheme.yellow,
              shape: BoxShape.circle,
              border: Border.all(color: DashboardTheme.black, width: 3),
              boxShadow: ShadowUtils.md,
            ),
            child: const Icon(
              Icons.phone_android_rounded,
              size: 44,
              color: DashboardTheme.black,
            ),
          ),
          const SizedBox(height: 20),
          const Text(
            'BELUM ADA DEVICE',
            style: TextStyle(
              color: DashboardTheme.black,
              fontSize: 16,
              fontWeight: FontWeight.w900,
              letterSpacing: 1.5,
            ),
          ),
          const SizedBox(height: 6),
          const Text(
            'Tidak ada perangkat yang terhubung',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: DashboardTheme.textMuted,
              fontSize: 12,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  MAIN DASHBOARD
// ═══════════════════════════════════════════════════════════════════
class DeviceDashboardPage extends StatefulWidget {
  final String username;
  final String role;
  final String sessionKey;

  const DeviceDashboardPage({
    super.key,
    this.username = '',
    this.role = '',
    this.sessionKey = '',
  });

  @override
  State<DeviceDashboardPage> createState() => _DDState();
}

class _DDState extends State<DeviceDashboardPage> {
  List<dynamic> _devices = [];
  bool _loading = true;
  String? _errorMsg;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _loadAll();
    _timer = Timer.periodic(const Duration(seconds: 20), (_) => _loadAll());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _loadAll() async {
    if (!mounted) return;
    try {
      final dRes = await http
          .get(Uri.parse(
              '$_kBase/rat/my-devices?key=${widget.sessionKey}'))
          .timeout(const Duration(seconds: 10));

      if (!mounted) return;
      if (dRes.statusCode != 200) {
        setState(() {
          _loading = false;
          _errorMsg = 'Server error ${dRes.statusCode}';
        });
        return;
      }

      final body = jsonDecode(dRes.body);
      if (body['valid'] != true) {
        setState(() {
          _loading = false;
          _errorMsg = body['message'] ?? 'Error';
        });
        return;
      }

      List<dynamic> devices = List<dynamic>.from(body['devices'] ?? []);
      final now = DateTime.now();
      for (var d in devices) {
        try {
          final seen = DateTime.parse(d['lastSeen']?.toString() ?? '');
          d['online'] = now.difference(seen).inSeconds < 30;
        } catch (_) {
          d['online'] = false;
        }
      }

      if (mounted) {
        setState(() {
          _devices = devices;
          _loading = false;
          _errorMsg = null;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _loading = false;
          _errorMsg = e.toString();
        });
      }
    }
  }

  Future<void> _refresh() async {
    setState(() => _loading = true);
    await _loadAll();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: DashboardTheme.bg,
      body: SafeArea(
        bottom: false,
        child: _loading
            ? _buildLoading()
            : _errorMsg != null
                ? _buildErrorView()
                : _DeviceListPage(
                    devices: _devices,
                    role: widget.role,
                  ),
      ),
    );
  }

  // ─── Loading State (Kotak kuning + spinner hitam) ─────────
  Widget _buildLoading() {
    return Center(
      child: Container(
        width: 70,
        height: 70,
        decoration: BoxDecoration(
          color: DashboardTheme.yellow,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: DashboardTheme.black, width: 3),
          boxShadow: ShadowUtils.md,
        ),
        child: const Center(
          child: SizedBox(
            width: 28,
            height: 28,
            child: CircularProgressIndicator(
              strokeWidth: 3,
              color: DashboardTheme.black,
            ),
          ),
        ),
      ),
    );
  }

  // ─── Error State ─────────────────────────────────────────
  Widget _buildErrorView() {
    return Center(
      child: _BrutalCard(
        padding: const EdgeInsets.all(24),
        bgColor: DashboardTheme.white,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: DashboardTheme.error,
                shape: BoxShape.circle,
                border: Border.all(color: DashboardTheme.black, width: 3),
                boxShadow: ShadowUtils.sm,
              ),
              child: const Icon(
                Icons.error_rounded,
                color: DashboardTheme.white,
                size: 44,
              ),
            ),
            const SizedBox(height: 18),
            const Text(
              'TERJADI KESALAHAN',
              style: TextStyle(
                color: DashboardTheme.black,
                fontSize: 14,
                fontWeight: FontWeight.w900,
                letterSpacing: 1.5,
              ),
            ),
            const SizedBox(height: 8),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Text(
                _errorMsg ?? 'Unknown error',
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: DashboardTheme.textMuted,
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            const SizedBox(height: 20),
            _RetryButton(onTap: _refresh),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  RETRY BUTTON (Neo-brutalism)
// ═══════════════════════════════════════════════════════════════════
class _RetryButton extends StatefulWidget {
  final VoidCallback onTap;
  const _RetryButton({required this.onTap});
  @override
  State<_RetryButton> createState() => _RetryButtonState();
}

class _RetryButtonState extends State<_RetryButton> {
  bool _pressed = false;
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) => setState(() => _pressed = false),
      onTapCancel: () => setState(() => _pressed = false),
      onTap: () {
        HapticFeedback.lightImpact();
        widget.onTap();
      },
      child: AnimatedScale(
        duration: const Duration(milliseconds: 90),
        scale: _pressed ? 0.95 : 1.0,
        child: Container(
          padding:
              const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
          decoration: BoxDecoration(
            color: DashboardTheme.black,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: DashboardTheme.black, width: 2.5),
            boxShadow: ShadowUtils.sm,
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: const [
              Icon(Icons.refresh_rounded,
                  color: DashboardTheme.yellow, size: 18),
              SizedBox(width: 8),
              Text(
                'COBA LAGI',
                style: TextStyle(
                  color: DashboardTheme.yellow,
                  fontWeight: FontWeight.w900,
                  fontSize: 12,
                  letterSpacing: 1.5,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}