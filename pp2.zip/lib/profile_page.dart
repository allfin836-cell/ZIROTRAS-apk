// ignore_for_file: use_build_context_synchronously
// profile_page.dart - NEO-BRUTALISM EDITION
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'change_password_page.dart';
import 'login_page.dart';

// ═══════════════════════════════════════════════════════════════════
//  NEO-BRUTALISM THEME
// ═══════════════════════════════════════════════════════════════════
class _T {
  static const bg        = Color(0xFFFFFFFF);
  static const white     = Color(0xFFFFFFFF);
  static const yellow    = Color(0xFFFFE600);
  static const yellowSoft = Color(0xFFFFF9CC);
  static const black     = Color(0xFF000000);
  static const textPrimary   = Color(0xFF000000);
  static const textSec       = Color(0xFF333333);
  static const textMuted     = Color(0xFF777777);
  static const success   = Color(0xFF00C853);
  static const error     = Color(0xFFFF1744);
  static const blue      = Color(0xFF2196F3);
  static const orange    = Color(0xFFFF9800);
}

class _S {
  static List<BoxShadow> get sm => const [
    BoxShadow(color: _T.black, offset: Offset(2, 2), blurRadius: 0),
  ];
  static List<BoxShadow> get md => const [
    BoxShadow(color: _T.black, offset: Offset(3, 3), blurRadius: 0),
  ];
  static List<BoxShadow> get lg => const [
    BoxShadow(color: _T.black, offset: Offset(5, 5), blurRadius: 0),
  ];
}

// ═══════════════════════════════════════════════════════════════════
//  PROFILE PAGE
// ═══════════════════════════════════════════════════════════════════
class ProfilePage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final String ratId;

  const ProfilePage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.ratId,
  });

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage>
    with TickerProviderStateMixin {
  late AnimationController _fadeCtrl;
  late AnimationController _slideCtrl;

  bool _showPassword = false;

  // Stats
  int _deviceOnline = 0;
  int _userOnline = 0;
  bool _statsLoading = true;

  @override
  void initState() {
    super.initState();

    _fadeCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 600))
      ..forward();
    _slideCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 700))
      ..forward();

    _fetchStats();
  }

  @override
  void dispose() {
    _fadeCtrl.dispose();
    _slideCtrl.dispose();
    super.dispose();
  }

  // ── Fetch stats ─────────────────────────────────────────────
  Future<void> _fetchStats() async {
    setState(() => _statsLoading = true);
    try {
      final res = await http.get(
        Uri.parse(
          'http://alfa-store-officials.alfamarket2.my.id:3583/api/user/profileStats?key=${widget.sessionKey}',
        ),
      ).timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      if (data['valid'] == true && mounted) {
        setState(() {
          _deviceOnline =
              (data['deviceOnline'] as num?)?.toInt() ?? 0;
          _userOnline = (data['userOnline'] as num?)?.toInt() ?? 0;
          _statsLoading = false;
        });
      }
    } catch (_) {
      if (mounted) setState(() => _statsLoading = false);
    }
  }

  // ── Helpers ────────────────────────────────────────────────
  Color _roleColor() {
    switch (widget.role.toLowerCase()) {
      case 'owner':
        return _T.error;
      case 'vip':
        return _T.orange;
      case 'reseller':
      case 'admin':
        return _T.success;
      default:
        return _T.blue;
    }
  }

  String _roleTitle() {
    switch (widget.role.toLowerCase()) {
      case 'owner':
        return 'Owner';
      case 'vip':
        return 'VIP';
      case 'reseller':
        return 'Reseller';
      case 'admin':
        return 'Admin';
      default:
        return 'Member';
    }
  }

  Future<void> _logout() async {
    final confirm = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (_) => _ConfirmDialog(
        title: 'Keluar',
        message: 'Yakin mau keluar dari akun ini?',
        confirmLabel: 'KELUAR',
        confirmColor: _T.error,
        icon: Icons.logout_rounded,
      ),
    );
    if (confirm != true) return;
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const LoginPage()),
      (r) => false,
    );
  }

  void _goChangePassword() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ProfileSettingsPage(
          username: widget.username,
          sessionKey: widget.sessionKey,
        ),
      ),
    );
  }

  void _copyRatId() {
    if (widget.ratId.isEmpty) return;
    Clipboard.setData(ClipboardData(text: widget.ratId));
    HapticFeedback.lightImpact();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Row(
          children: [
            Icon(Icons.copy_rounded, color: _T.yellow, size: 18),
            SizedBox(width: 8),
            Text(
              'RAT ID disalin!',
              style: TextStyle(
                color: _T.yellow,
                fontWeight: FontWeight.w900,
              ),
            ),
          ],
        ),
        backgroundColor: _T.black,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: const BorderSide(color: _T.black, width: 2),
        ),
        margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  // ── Build ──────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _T.bg,
      body: Stack(
        children: [
          // Dot pattern halus di background
          Positioned.fill(
            child: CustomPaint(painter: _DotPatternPainter()),
          ),
          SafeArea(
            child: FadeTransition(
              opacity: _fadeCtrl,
              child: Column(
                children: [
                  _buildTopBar(),
                  Expanded(
                    child: SingleChildScrollView(
                      physics: const BouncingScrollPhysics(),
                      padding:
                          const EdgeInsets.symmetric(horizontal: 20),
                      child: Column(
                        children: [
                          const SizedBox(height: 12),
                          _buildAvatar(),
                          const SizedBox(height: 20),
                          _buildStatsCard(),
                          const SizedBox(height: 16),
                          _buildInfoCard(),
                          const SizedBox(height: 16),
                          _buildActionButtons(),
                          const SizedBox(height: 32),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── Top bar ────────────────────────────────────────────────
  Widget _buildTopBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      child: Row(
        children: [
          _IconBtn(
            icon: Icons.arrow_back_ios_new_rounded,
            onTap: () => Navigator.pop(context),
          ),
          const Spacer(),
          const Text(
            'PROFILE',
            style: TextStyle(
              color: _T.black,
              fontSize: 14,
              fontWeight: FontWeight.w900,
              letterSpacing: 3,
            ),
          ),
          const Spacer(),
          const SizedBox(width: 38),
        ],
      ),
    );
  }

  // ── Avatar ─────────────────────────────────────────────────
  Widget _buildAvatar() {
    final roleColor = _roleColor();
    return Column(
      children: [
        // Avatar kotak kuning border hitam tebal
        Container(
          padding: const EdgeInsets.all(5),
          decoration: BoxDecoration(
            color: _T.yellow,
            borderRadius: BorderRadius.circular(28),
            border: Border.all(color: _T.black, width: 4),
            boxShadow: _S.lg,
          ),
          child: Container(
            width: 100,
            height: 100,
            decoration: BoxDecoration(
              color: _T.white,
              borderRadius: BorderRadius.circular(22),
              border: Border.all(color: _T.black, width: 2.5),
            ),
            clipBehavior: Clip.antiAlias,
            child: Image.asset(
              'assets/images/logo.png',
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => const Icon(
                Icons.person_rounded,
                color: _T.black,
                size: 48,
              ),
            ),
          ),
        ),
        const SizedBox(height: 16),
        // Username
        Text(
          widget.username,
          style: const TextStyle(
            color: _T.black,
            fontSize: 22,
            fontWeight: FontWeight.w900,
            letterSpacing: 1.2,
          ),
        ),
        const SizedBox(height: 8),
        // Role badge
        Container(
          padding:
              const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
          decoration: BoxDecoration(
            color: roleColor,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _T.black, width: 2.5),
            boxShadow: _S.sm,
          ),
          child: Text(
            _roleTitle().toUpperCase(),
            style: const TextStyle(
              color: _T.white,
              fontSize: 10,
              fontWeight: FontWeight.w900,
              letterSpacing: 2,
            ),
          ),
        ),
      ],
    );
  }

  // ── Stats card ─────────────────────────────────────────────
  Widget _buildStatsCard() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
      decoration: BoxDecoration(
        color: _T.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: _T.black, width: 3),
        boxShadow: _S.md,
      ),
      child: _statsLoading
          ? const Center(
              child: SizedBox(
                height: 32,
                width: 32,
                child: CircularProgressIndicator(
                  strokeWidth: 3,
                  color: _T.black,
                ),
              ),
            )
          : Row(
              children: [
                Expanded(
                  child: _statItem(
                    value: _deviceOnline.toString(),
                    label: 'DEVICE',
                    sublabel: 'ONLINE',
                    color: _T.success,
                    icon: Icons.phone_android_rounded,
                  ),
                ),
                _statDivider(),
                Expanded(
                  child: _statItem(
                    value: _userOnline.toString(),
                    label: 'USER',
                    sublabel: 'ONLINE',
                    color: _T.blue,
                    icon: Icons.people_rounded,
                  ),
                ),
              ],
            ),
    );
  }

  Widget _statItem({
    required String value,
    required String label,
    required String sublabel,
    required Color color,
    required IconData icon,
  }) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            color: _T.yellow,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: _T.black, width: 2.5),
            boxShadow: _S.sm,
          ),
          child: Icon(icon, color: _T.black, size: 18),
        ),
        const SizedBox(height: 10),
        Text(
          value,
          style: TextStyle(
            color: color,
            fontSize: 24,
            fontWeight: FontWeight.w900,
            height: 1,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          '$label\n$sublabel',
          textAlign: TextAlign.center,
          style: const TextStyle(
            color: _T.textMuted,
            fontSize: 9,
            fontWeight: FontWeight.w900,
            letterSpacing: 1.2,
            height: 1.3,
          ),
        ),
      ],
    );
  }

  Widget _statDivider() {
    return Container(
      width: 2.5,
      height: 60,
      color: _T.black,
      margin: const EdgeInsets.symmetric(horizontal: 6),
    );
  }

  // ── Info card ──────────────────────────────────────────────
  Widget _buildInfoCard() {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: _T.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: _T.black, width: 3),
        boxShadow: _S.md,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: _T.yellow,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: _T.black, width: 2.5),
                  boxShadow: _S.sm,
                ),
                child: const Icon(Icons.info_outline_rounded,
                    color: _T.black, size: 16),
              ),
              const SizedBox(width: 10),
              const Text(
                'INFORMASI AKUN',
                style: TextStyle(
                  color: _T.black,
                  fontSize: 12,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 2,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          // Username
          _infoRow(
            icon: Icons.alternate_email_rounded,
            label: 'Username',
            value: widget.username,
          ),
          const SizedBox(height: 10),
          // Password
          _passwordRow(),
          const SizedBox(height: 10),
          // RAT ID
          _ratIdRow(),
        ],
      ),
    );
  }

  Widget _infoRow({
    required IconData icon,
    required String label,
    required String value,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: _T.yellowSoft,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _T.black, width: 2),
      ),
      child: Row(
        children: [
          Container(
            width: 34,
            height: 34,
            decoration: BoxDecoration(
              color: _T.yellow,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: _T.black, width: 2),
            ),
            child: Icon(icon, color: _T.black, size: 16),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label.toUpperCase(),
                  style: const TextStyle(
                    color: _T.textMuted,
                    fontSize: 10,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.2,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  value,
                  style: const TextStyle(
                    color: _T.black,
                    fontSize: 13,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _passwordRow() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: _T.yellowSoft,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _T.black, width: 2),
      ),
      child: Row(
        children: [
          Container(
            width: 34,
            height: 34,
            decoration: BoxDecoration(
              color: _T.yellow,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: _T.black, width: 2),
            ),
            child: const Icon(Icons.lock_outline_rounded,
                color: _T.black, size: 16),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'PASSWORD',
                  style: TextStyle(
                    color: _T.textMuted,
                    fontSize: 10,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.2,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  _showPassword ? widget.password : '••••••••',
                  style: const TextStyle(
                    color: _T.black,
                    fontSize: 13,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 2,
                  ),
                ),
              ],
            ),
          ),
          GestureDetector(
            onTap: () {
              HapticFeedback.selectionClick();
              setState(() => _showPassword = !_showPassword);
            },
            child: Container(
              width: 34,
              height: 34,
              decoration: BoxDecoration(
                color: _T.white,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: _T.black, width: 2),
              ),
              child: Icon(
                _showPassword
                    ? Icons.visibility_off_outlined
                    : Icons.visibility_outlined,
                color: _T.black,
                size: 16,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _ratIdRow() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: _T.yellowSoft,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _T.black, width: 2),
      ),
      child: Row(
        children: [
          Container(
            width: 34,
            height: 34,
            decoration: BoxDecoration(
              color: _T.yellow,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: _T.black, width: 2),
            ),
            child: const Icon(Icons.fingerprint_rounded,
                color: _T.black, size: 16),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'RAT ID',
                  style: TextStyle(
                    color: _T.textMuted,
                    fontSize: 10,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.2,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  widget.ratId.isEmpty ? 'N/A' : widget.ratId,
                  style: const TextStyle(
                    color: _T.black,
                    fontSize: 12,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
          GestureDetector(
            onTap: _copyRatId,
            child: Container(
              width: 34,
              height: 34,
              decoration: BoxDecoration(
                color: _T.yellow,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: _T.black, width: 2),
                boxShadow: _S.sm,
              ),
              child: const Icon(Icons.copy_rounded,
                  color: _T.black, size: 15),
            ),
          ),
        ],
      ),
    );
  }

  // ── Action buttons ─────────────────────────────────────────
  Widget _buildActionButtons() {
    return Column(
      children: [
        // Dashboard
        _actionButton(
          icon: Icons.home_rounded,
          label: 'Kembali ke Dashboard',
          onTap: () => Navigator.pop(context),
          bgColor: _T.white,
          textColor: _T.black,
        ),
        const SizedBox(height: 10),
        // Ubah Password
        _actionButton(
          icon: Icons.lock_reset_rounded,
          label: 'Ubah Password',
          onTap: _goChangePassword,
          bgColor: _T.yellow,
          textColor: _T.black,
        ),
        const SizedBox(height: 10),
        // Logout
        _actionButton(
          icon: Icons.logout_rounded,
          label: 'Keluar',
          onTap: _logout,
          bgColor: _T.error,
          textColor: _T.white,
        ),
      ],
    );
  }

  Widget _actionButton({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    required Color bgColor,
    required Color textColor,
  }) {
    return _PressBtn(
      onTap: () {
        HapticFeedback.selectionClick();
        onTap();
      },
      child: Container(
        height: 54,
        decoration: BoxDecoration(
          color: bgColor,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: _T.black, width: 2.5),
          boxShadow: _S.sm,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: textColor, size: 18),
            const SizedBox(width: 10),
            Text(
              label,
              style: TextStyle(
                color: textColor,
                fontSize: 14,
                fontWeight: FontWeight.w900,
                letterSpacing: 0.8,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  CONFIRM DIALOG (Neo-Brutalism)
// ═══════════════════════════════════════════════════════════════════
class _ConfirmDialog extends StatelessWidget {
  final String title;
  final String message;
  final String confirmLabel;
  final Color confirmColor;
  final IconData icon;

  const _ConfirmDialog({
    required this.title,
    required this.message,
    required this.confirmLabel,
    required this.confirmColor,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 32),
      child: Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          color: _T.yellow,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: _T.black, width: 3),
          boxShadow: _S.md,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: confirmColor,
                shape: BoxShape.circle,
                border: Border.all(color: _T.black, width: 3),
                boxShadow: _S.sm,
              ),
              child: Icon(icon, color: _T.white, size: 28),
            ),
            const SizedBox(height: 16),
            Text(
              title.toUpperCase(),
              style: const TextStyle(
                color: _T.black,
                fontSize: 16,
                fontWeight: FontWeight.w900,
                letterSpacing: 2,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              message,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: _T.textSec,
                fontSize: 13,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 22),
            Row(
              children: [
                Expanded(
                  child: _PressBtn(
                    onTap: () => Navigator.pop(context, false),
                    child: Container(
                      height: 46,
                      decoration: BoxDecoration(
                        color: _T.white,
                        borderRadius: BorderRadius.circular(12),
                        border:
                            Border.all(color: _T.black, width: 2.5),
                      ),
                      child: const Center(
                        child: Text(
                          'BATAL',
                          style: TextStyle(
                            color: _T.black,
                            fontWeight: FontWeight.w900,
                            fontSize: 13,
                            letterSpacing: 1,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _PressBtn(
                    onTap: () => Navigator.pop(context, true),
                    child: Container(
                      height: 46,
                      decoration: BoxDecoration(
                        color: confirmColor,
                        borderRadius: BorderRadius.circular(12),
                        border:
                            Border.all(color: _T.black, width: 2.5),
                      ),
                      child: Center(
                        child: Text(
                          confirmLabel,
                          style: const TextStyle(
                            color: _T.white,
                            fontWeight: FontWeight.w900,
                            fontSize: 13,
                            letterSpacing: 1,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  PRESS BUTTON WRAPPER (Haptic + Scale)
// ═══════════════════════════════════════════════════════════════════
class _PressBtn extends StatefulWidget {
  final Widget child;
  final VoidCallback onTap;
  const _PressBtn({required this.child, required this.onTap});

  @override
  State<_PressBtn> createState() => _PressBtnState();
}

class _PressBtnState extends State<_PressBtn> {
  bool _pressed = false;
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) => setState(() => _pressed = false),
      onTapCancel: () => setState(() => _pressed = false),
      onTap: widget.onTap,
      child: AnimatedScale(
        duration: const Duration(milliseconds: 90),
        scale: _pressed ? 0.96 : 1.0,
        child: widget.child,
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  ICON BUTTON
// ═══════════════════════════════════════════════════════════════════
class _IconBtn extends StatefulWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _IconBtn({required this.icon, required this.onTap});

  @override
  State<_IconBtn> createState() => _IconBtnState();
}

class _IconBtnState extends State<_IconBtn> {
  bool _pressed = false;
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) => setState(() => _pressed = false),
      onTapCancel: () => setState(() => _pressed = false),
      onTap: () {
        HapticFeedback.lightImpact();
        widget.onTap();
      },
      child: AnimatedScale(
        duration: const Duration(milliseconds: 90),
        scale: _pressed ? 0.9 : 1.0,
        child: Container(
          width: 38,
          height: 38,
          decoration: BoxDecoration(
            color: _T.yellow,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: _T.black, width: 2.5),
            boxShadow: _S.sm,
          ),
          child: Icon(widget.icon, color: _T.black, size: 16),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  DOT PATTERN BACKGROUND
// ═══════════════════════════════════════════════════════════════════
class _DotPatternPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = _T.yellow.withOpacity(0.35)
      ..style = PaintingStyle.fill;

    const spacing = 24.0;
    const dotRadius = 1.5;

    for (double x = 0; x < size.width; x += spacing) {
      for (double y = 0; y < size.height; y += spacing) {
        canvas.drawCircle(Offset(x, y), dotRadius, paint);
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}