// owner_page.dart - NEO-BRUTALISM EDITION
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

const String _baseUrl = 'http://alfa-store-officials.alfamarket2.my.id:3583';

// ═══════════════════════════════════════════════════════════════════
//  NEO-BRUTALISM THEME
// ═══════════════════════════════════════════════════════════════════
class _T {
  static const bg       = Color(0xFFFFFFFF);
  static const surface  = Color(0xFFFFFFFF);
  static const surface2 = Color(0xFFFFF9CC);
  static const yellow   = Color(0xFFFFE600);
  static const yellowDark = Color(0xFFF5D400);
  static const black    = Color(0xFF000000);
  static const white    = Color(0xFFFFFFFF);
  static const textPrimary = Color(0xFF000000);
  static const textSec     = Color(0xFF333333);
  static const textMuted   = Color(0xFF777777);
  static const success = Color(0xFF00C853);
  static const warning = Color(0xFFFFAB40);
  static const error   = Color(0xFFFF1744);
}

class _S {
  static List<BoxShadow> get sm => const [
    BoxShadow(color: _T.black, offset: Offset(2, 2), blurRadius: 0),
  ];
  static List<BoxShadow> get md => const [
    BoxShadow(color: _T.black, offset: Offset(3, 3), blurRadius: 0),
  ];
  static List<BoxShadow> get lg => const [
    BoxShadow(color: _T.black, offset: Offset(5, 5), blurRadius: 0),
  ];
}

// ═══════════════════════════════════════════════════════════════════
//  OWNER PAGE
// ═══════════════════════════════════════════════════════════════════
class OwnerPage extends StatefulWidget {
  final String sessionKey;
  final String username;

  const OwnerPage({
    super.key,
    required this.sessionKey,
    required this.username,
  });

  @override
  State<OwnerPage> createState() => _OwnerPageState();
}

class _OwnerPageState extends State<OwnerPage> {
  late String sessionKey;

  List<dynamic> fullUserList = [];
  List<dynamic> filteredList = [];

  final List<String> roleOptions = [
    'owner',
    'admin',
    'vip',
    'reseller',
    'member'
  ];
  String selectedRole = 'member';

  int currentPage = 1;
  int itemsPerPage = 25;

  final createUsernameController = TextEditingController();
  final createPasswordController = TextEditingController();
  final createDayController = TextEditingController();
  final deleteController = TextEditingController();
  final editUsernameController = TextEditingController();
  final editDayController = TextEditingController();

  String newUserRole = 'member';
  bool isLoading = false;

  int _section = 0;

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    _fetchUsers();
  }

  @override
  void dispose() {
    createUsernameController.dispose();
    createPasswordController.dispose();
    createDayController.dispose();
    deleteController.dispose();
    editUsernameController.dispose();
    editDayController.dispose();
    super.dispose();
  }

  // ─── API CALLS ─────────────────────────────────────────────
  Future<void> _fetchUsers() async {
    setState(() => isLoading = true);
    try {
      final res =
          await http.get(Uri.parse('$_baseUrl/listUsers?key=$sessionKey'));
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['authorized'] == true) {
        fullUserList = data['users'] ?? [];
        _filterAndPaginate();
      } else {
        _alert("Info", data['message'] ?? 'Gagal memuat user.');
      }
    } catch (_) {
      _alert("Error", "Gagal terhubung ke server.");
    }
    if (mounted) setState(() => isLoading = false);
  }

  void _filterAndPaginate() {
    setState(() {
      currentPage = 1;
      filteredList =
          fullUserList.where((u) => u['role'] == selectedRole).toList();
    });
  }

  List<dynamic> _getCurrentPageData() {
    final start = (currentPage - 1) * itemsPerPage;
    final end = (start + itemsPerPage);
    return filteredList.sublist(
      start,
      end > filteredList.length ? filteredList.length : end,
    );
  }

  int get totalPages =>
      (filteredList.length / itemsPerPage).ceil().clamp(1, 999999);

  Map<String, int> get _roleCounts {
    final map = <String, int>{};
    for (final r in roleOptions) {
      map[r] = fullUserList.where((u) => u['role'] == r).length;
    }
    return map;
  }

  Future<void> _deleteUser() async {
    final username = deleteController.text.trim();
    if (username.isEmpty) {
      _alert("Peringatan", "Masukkan username yang ingin dihapus.");
      return;
    }

    setState(() => isLoading = true);
    try {
      final res = await http.get(
        Uri.parse('$_baseUrl/deleteUser?key=$sessionKey&username=$username'),
      );
      final data = jsonDecode(res.body);

      if (data['deleted'] == true) {
        _alert("Sukses", "User berhasil dihapus.");
        deleteController.clear();
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal menghapus user.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    if (mounted) setState(() => isLoading = false);
  }

  Future<void> _createAccount() async {
    final u = createUsernameController.text.trim();
    final p = createPasswordController.text.trim();
    final d = createDayController.text.trim();

    if (u.isEmpty || p.isEmpty || d.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.");
      return;
    }

    setState(() => isLoading = true);
    try {
      final url = Uri.parse(
        '$_baseUrl/userAdd?key=$sessionKey&username=$u&password=$p&day=$d&role=$newUserRole',
      );
      final res = await http.get(url);
      final data = jsonDecode(res.body);

      if (data['created'] == true) {
        _alert("Sukses",
            "Akun berhasil dibuat sebagai ${newUserRole.toUpperCase()}.");
        createUsernameController.clear();
        createPasswordController.clear();
        createDayController.clear();
        newUserRole = 'member';
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal membuat akun.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    if (mounted) setState(() => isLoading = false);
  }

  Future<void> _editUser() async {
    final u = editUsernameController.text.trim();
    final d = editDayController.text.trim();

    if (u.isEmpty || d.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.");
      return;
    }

    setState(() => isLoading = true);
    try {
      final url = Uri.parse(
        '$_baseUrl/editUser?key=$sessionKey&username=$u&addDays=$d',
      );
      final res = await http.get(url);
      final data = jsonDecode(res.body);

      if (data['edited'] == true) {
        _alert("Sukses", "Durasi berhasil diperbarui.");
        editUsernameController.clear();
        editDayController.clear();
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal mengubah durasi.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    if (mounted) setState(() => isLoading = false);
  }

  // ─── ALERT (Neo-Brutalism) ─────────────────────────────────
  void _alert(String title, String message) {
    HapticFeedback.lightImpact();
    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: _T.yellow,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _T.black, width: 3),
            boxShadow: _S.md,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: _T.white,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: _T.black, width: 2.5),
                    ),
                    child: const Icon(Icons.info_outline_rounded,
                        color: _T.black, size: 20),
                  ),
                  const SizedBox(width: 10),
                  Text(
                    title.toUpperCase(),
                    style: const TextStyle(
                      color: _T.black,
                      fontSize: 15,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              Text(
                message,
                style: const TextStyle(
                  color: _T.textSec,
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 18),
              Align(
                alignment: Alignment.centerRight,
                child: GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 24, vertical: 10),
                    decoration: BoxDecoration(
                      color: _T.black,
                      borderRadius: BorderRadius.circular(10),
                      border:
                          Border.all(color: _T.black, width: 2.5),
                      boxShadow: _S.sm,
                    ),
                    child: const Text(
                      'OK',
                      style: TextStyle(
                        color: _T.yellow,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ─── INPUT FIELD ───────────────────────────────────────────
  Widget _buildInput({
    required String label,
    required TextEditingController controller,
    required IconData icon,
    TextInputType type = TextInputType.text,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Container(
        decoration: BoxDecoration(
          color: _T.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: _T.black, width: 2.5),
        ),
        child: TextField(
          controller: controller,
          keyboardType: type,
          style: const TextStyle(
            color: _T.black,
            fontWeight: FontWeight.w700,
            fontSize: 14,
          ),
          decoration: InputDecoration(
            labelText: label,
            labelStyle: const TextStyle(
              color: _T.textMuted,
              fontSize: 12,
              fontWeight: FontWeight.w700,
            ),
            floatingLabelStyle: const TextStyle(
              color: _T.black,
              fontWeight: FontWeight.w900,
            ),
            prefixIcon: Icon(icon, color: _T.black, size: 18),
            border: InputBorder.none,
            focusedBorder: InputBorder.none,
            enabledBorder: InputBorder.none,
            contentPadding:
                const EdgeInsets.symmetric(vertical: 14, horizontal: 4),
          ),
        ),
      ),
    );
  }

  // ─── PANEL WRAPPER ─────────────────────────────────────────
  Widget _panel({
    required Widget child,
    EdgeInsetsGeometry? padding,
    Color? bgColor,
  }) {
    return Container(
      width: double.infinity,
      padding: padding ?? const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: bgColor ?? _T.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _T.black, width: 2.5),
        boxShadow: _S.md,
      ),
      child: child,
    );
  }

  // ─── BUTTON (Kuning solid) ─────────────────────────────────
  Widget _yellowButton({
    required String label,
    required IconData icon,
    required VoidCallback? onTap,
    bool isError = false,
  }) {
    return SizedBox(
      width: double.infinity,
      height: 50,
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 100),
          decoration: BoxDecoration(
            color: isError ? _T.error : _T.yellow,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: _T.black, width: 2.5),
            boxShadow: _S.sm,
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (isLoading)
                const SizedBox(
                  width: 16,
                  height: 16,
                  child: CircularProgressIndicator(
                    strokeWidth: 2.5,
                    color: _T.black,
                  ),
                )
              else
                Icon(icon,
                    size: 18,
                    color: isError ? _T.white : _T.black),
              const SizedBox(width: 8),
              Text(
                label.toUpperCase(),
                style: TextStyle(
                  color: isError ? _T.white : _T.black,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.2,
                  fontSize: 12,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ─── ROLE DROPDOWN ─────────────────────────────────────────
  Widget _roleDropdown(String value, ValueChanged<String?> onChanged) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 2),
      decoration: BoxDecoration(
        color: _T.yellow,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _T.black, width: 2.5),
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: value,
          isExpanded: true,
          dropdownColor: _T.yellow,
          icon: const Icon(Icons.expand_more_rounded, color: _T.black),
          style: const TextStyle(
            color: _T.black,
            fontWeight: FontWeight.w900,
            fontSize: 13,
          ),
          items: roleOptions.map((role) {
            return DropdownMenuItem(
              value: role,
              child: Text(
                role.toUpperCase(),
                style: const TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w900,
                  color: _T.black,
                ),
              ),
            );
          }).toList(),
          onChanged: onChanged,
        ),
      ),
    );
  }

  // ─── USER ITEM ─────────────────────────────────────────────
  Widget _buildUserItem(Map user) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: _T.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _T.black, width: 2.5),
        boxShadow: _S.sm,
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(9),
            decoration: BoxDecoration(
              color: _T.yellow,
              shape: BoxShape.circle,
              border: Border.all(color: _T.black, width: 2.5),
            ),
            child: const Icon(Icons.person_rounded,
                color: _T.black, size: 18),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  user['username'],
                  style: const TextStyle(
                    color: _T.black,
                    fontWeight: FontWeight.w900,
                    fontSize: 14,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  "${user['role'].toString().toUpperCase()}  •  EXP ${user['expiredDate']}",
                  style: const TextStyle(
                    color: _T.textSec,
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
          GestureDetector(
            onTap: () async {
              HapticFeedback.lightImpact();
              final confirm = await showDialog<bool>(
                context: context,
                builder: (_) => Dialog(
                  backgroundColor: Colors.transparent,
                  child: Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: _T.white,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: _T.black, width: 3),
                      boxShadow: _S.md,
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: _T.error,
                            shape: BoxShape.circle,
                            border: Border.all(
                                color: _T.black, width: 2.5),
                          ),
                          child: const Icon(Icons.warning_amber_rounded,
                              color: _T.white, size: 28),
                        ),
                        const SizedBox(height: 14),
                        const Text(
                          'HAPUS USER?',
                          style: TextStyle(
                            color: _T.black,
                            fontSize: 15,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          'User ${user['username']} akan dihapus permanen.',
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            color: _T.textSec,
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const SizedBox(height: 18),
                        Row(
                          children: [
                            Expanded(
                              child: GestureDetector(
                                onTap: () =>
                                    Navigator.pop(context, false),
                                child: Container(
                                  padding: const EdgeInsets.symmetric(
                                      vertical: 10),
                                  decoration: BoxDecoration(
                                    color: _T.white,
                                    borderRadius:
                                        BorderRadius.circular(10),
                                    border: Border.all(
                                        color: _T.black, width: 2.5),
                                  ),
                                  child: const Center(
                                    child: Text(
                                      'BATAL',
                                      style: TextStyle(
                                        color: _T.black,
                                        fontWeight: FontWeight.w900,
                                        letterSpacing: 1,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: GestureDetector(
                                onTap: () =>
                                    Navigator.pop(context, true),
                                child: Container(
                                  padding: const EdgeInsets.symmetric(
                                      vertical: 10),
                                  decoration: BoxDecoration(
                                    color: _T.error,
                                    borderRadius:
                                        BorderRadius.circular(10),
                                    border: Border.all(
                                        color: _T.black, width: 2.5),
                                  ),
                                  child: const Center(
                                    child: Text(
                                      'HAPUS',
                                      style: TextStyle(
                                        color: _T.white,
                                        fontWeight: FontWeight.w900,
                                        letterSpacing: 1,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              );
              if (confirm == true) {
                deleteController.text = user['username'];
                _deleteUser();
              }
            },
            child: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: _T.error,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: _T.black, width: 2),
              ),
              child: const Icon(Icons.delete_outline_rounded,
                  color: _T.white, size: 16),
            ),
          ),
        ],
      ),
    );
  }

  // ─── PAGINATION ────────────────────────────────────────────
  Widget _buildPagination() {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: List.generate(totalPages, (index) {
        final page = index + 1;
        final active = currentPage == page;
        return GestureDetector(
          onTap: () {
            HapticFeedback.lightImpact();
            setState(() => currentPage = page);
          },
          child: Container(
            width: 36,
            height: 36,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: active ? _T.yellow : _T.white,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: _T.black, width: 2),
              boxShadow: active ? _S.sm : null,
            ),
            child: Text(
              "$page",
              style: const TextStyle(
                color: _T.black,
                fontSize: 12,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
        );
      }),
    );
  }

  // ─── SECTION LABEL ─────────────────────────────────────────
  Widget _sectionLabel(String text, IconData icon) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(9),
          decoration: BoxDecoration(
            color: _T.yellow,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: _T.black, width: 2.5),
            boxShadow: _S.sm,
          ),
          child: Icon(icon, color: _T.black, size: 16),
        ),
        const SizedBox(width: 10),
        Text(
          text,
          style: const TextStyle(
            color: _T.black,
            fontSize: 15,
            fontWeight: FontWeight.w900,
            letterSpacing: 1.2,
          ),
        ),
      ],
    );
  }

  // ─── QUICK ACTION TILE ─────────────────────────────────────
  Widget _quickActionTile({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: () {
        HapticFeedback.lightImpact();
        onTap();
      },
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 18),
        decoration: BoxDecoration(
          color: _T.yellow,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _T.black, width: 2.5),
          boxShadow: _S.sm,
        ),
        child: Column(
          children: [
            Icon(icon, color: _T.black, size: 22),
            const SizedBox(height: 8),
            Text(
              label,
              style: const TextStyle(
                color: _T.black,
                fontSize: 12,
                fontWeight: FontWeight.w900,
              ),
            ),
          ],
        ),
      ),
    );
  }

  IconData _roleIconFor(String role) {
    switch (role) {
      case 'owner':
        return Icons.workspace_premium_rounded;
      case 'admin':
        return Icons.admin_panel_settings_rounded;
      case 'vip':
        return Icons.star_rounded;
      case 'reseller':
        return Icons.storefront_rounded;
      default:
        return Icons.person_rounded;
    }
  }

  // ─── ROLE CARD ─────────────────────────────────────────────
  Widget _roleCard(String role, Map<String, int> counts) {
    return Expanded(
      child: GestureDetector(
        onTap: () {
          HapticFeedback.lightImpact();
          setState(() {
            selectedRole = role;
            _filterAndPaginate();
            _section = 1;
          });
        },
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: _T.white,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: _T.black, width: 2.5),
            boxShadow: _S.sm,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(7),
                decoration: BoxDecoration(
                  color: _T.yellow,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: _T.black, width: 2),
                ),
                child: Icon(_roleIconFor(role),
                    color: _T.black, size: 14),
              ),
              const SizedBox(height: 10),
              Text(
                "${counts[role] ?? 0}",
                style: const TextStyle(
                  color: _T.black,
                  fontSize: 22,
                  fontWeight: FontWeight.w900,
                  height: 1,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                role.toUpperCase(),
                style: const TextStyle(
                  color: _T.textSec,
                  fontSize: 10,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildRoleGrid(Map<String, int> counts) {
    final roles = roleOptions;
    final rows = <Widget>[];
    for (int i = 0; i < roles.length; i += 2) {
      final isLast = i + 1 >= roles.length;
      rows.add(
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _roleCard(roles[i], counts),
            const SizedBox(width: 12),
            if (!isLast)
              _roleCard(roles[i + 1], counts)
            else
              const Expanded(child: SizedBox()),
          ],
        ),
      );
      if (i + 2 < roles.length) rows.add(const SizedBox(height: 12));
    }
    return Column(children: rows);
  }

  // ═══════════════════════════════════════════════════════════
  //  SECTIONS
  // ═══════════════════════════════════════════════════════════

  // ─── HOME ─────────────────────────────────────────────────
  Widget _homeSection() {
    final counts = _roleCounts;
    final total = fullUserList.length;

    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 110),
      physics: const BouncingScrollPhysics(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Total users card
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: _T.yellow,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: _T.black, width: 3),
              boxShadow: _S.md,
            ),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        "TOTAL USERS",
                        style: TextStyle(
                          color: _T.black,
                          fontSize: 11,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 2,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        "$total",
                        style: const TextStyle(
                          color: _T.black,
                          fontSize: 42,
                          fontWeight: FontWeight.w900,
                          height: 1,
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: _T.black,
                    shape: BoxShape.circle,
                    border: Border.all(color: _T.black, width: 3),
                    boxShadow: _S.sm,
                  ),
                  child: const Icon(
                    FontAwesomeIcons.users,
                    color: _T.yellow,
                    size: 24,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 22),
          const Text(
            "DISTRIBUSI ROLE",
            style: TextStyle(
              color: _T.black,
              fontSize: 11,
              fontWeight: FontWeight.w900,
              letterSpacing: 1.5,
            ),
          ),
          const SizedBox(height: 12),
          _buildRoleGrid(counts),
          const SizedBox(height: 22),
          const Text(
            "QUICK ACTIONS",
            style: TextStyle(
              color: _T.black,
              fontSize: 11,
              fontWeight: FontWeight.w900,
              letterSpacing: 1.5,
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: _quickActionTile(
                  icon: Icons.person_add_alt_1_rounded,
                  label: "Buat Akun",
                  onTap: () => setState(() => _section = 2),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _quickActionTile(
                  icon: Icons.tune_rounded,
                  label: "Kelola User",
                  onTap: () => setState(() => _section = 3),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ─── USERS ────────────────────────────────────────────────
  Widget _usersSection() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
          child: _sectionLabel("USER LIST", FontAwesomeIcons.users),
        ),
        const SizedBox(height: 12),
        SizedBox(
          height: 42,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            itemCount: roleOptions.length,
            separatorBuilder: (_, __) => const SizedBox(width: 8),
            itemBuilder: (_, i) {
              final role = roleOptions[i];
              final active = selectedRole == role;
              return GestureDetector(
                onTap: () {
                  HapticFeedback.lightImpact();
                  setState(() {
                    selectedRole = role;
                    _filterAndPaginate();
                  });
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: active ? _T.yellow : _T.white,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: _T.black, width: 2.5),
                    boxShadow: active ? _S.sm : null,
                  ),
                  child: Text(
                    role.toUpperCase(),
                    style: const TextStyle(
                      color: _T.black,
                      fontSize: 11,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1,
                    ),
                  ),
                ),
              );
            },
          ),
        ),
        const SizedBox(height: 14),
        Expanded(
          child: isLoading
              ? Center(
                  child: Container(
                    width: 60,
                    height: 60,
                    decoration: BoxDecoration(
                      color: _T.yellow,
                      borderRadius: BorderRadius.circular(16),
                      border:
                          Border.all(color: _T.black, width: 3),
                      boxShadow: _S.md,
                    ),
                    child: const Center(
                      child: SizedBox(
                        width: 26,
                        height: 26,
                        child: CircularProgressIndicator(
                          strokeWidth: 3,
                          color: _T.black,
                        ),
                      ),
                    ),
                  ),
                )
              : filteredList.isEmpty
                  ? Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Container(
                            padding: const EdgeInsets.all(18),
                            decoration: BoxDecoration(
                              color: _T.yellow,
                              shape: BoxShape.circle,
                              border: Border.all(
                                  color: _T.black, width: 3),
                              boxShadow: _S.md,
                            ),
                            child: const Icon(
                                Icons.person_off_rounded,
                                color: _T.black,
                                size: 36),
                          ),
                          const SizedBox(height: 14),
                          const Text(
                            "Tidak ada user",
                            style: TextStyle(
                              color: _T.black,
                              fontSize: 14,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            "Belum ada user dengan role ${selectedRole.toUpperCase()}",
                            style: const TextStyle(
                              color: _T.textMuted,
                              fontSize: 11,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    )
                  : SingleChildScrollView(
                      padding:
                          const EdgeInsets.fromLTRB(16, 0, 16, 110),
                      physics: const BouncingScrollPhysics(),
                      child: Column(
                        children: [
                          ..._getCurrentPageData()
                              .map((u) => _buildUserItem(u)),
                          const SizedBox(height: 10),
                          _buildPagination(),
                        ],
                      ),
                    ),
        ),
      ],
    );
  }

  // ─── CREATE ───────────────────────────────────────────────
  Widget _createSection() {
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(16, 20, 16, 110),
      physics: const BouncingScrollPhysics(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Center(
            child: Container(
              width: 64,
              height: 64,
              decoration: BoxDecoration(
                color: _T.yellow,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: _T.black, width: 3),
                boxShadow: _S.md,
              ),
              child: const Icon(Icons.person_add_alt_1_rounded,
                  color: _T.black, size: 28),
            ),
          ),
          const SizedBox(height: 14),
          const Center(
            child: Text(
              "Buat Akun Baru",
              style: TextStyle(
                color: _T.black,
                fontSize: 18,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
          const SizedBox(height: 4),
          const Center(
            child: Text(
              "Isi data di bawah untuk membuat akun",
              style: TextStyle(
                color: _T.textMuted,
                fontSize: 12,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          const SizedBox(height: 22),
          _panel(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                _buildInput(
                  label: "Username",
                  controller: createUsernameController,
                  icon: FontAwesomeIcons.user,
                ),
                _buildInput(
                  label: "Password",
                  controller: createPasswordController,
                  icon: FontAwesomeIcons.lock,
                ),
                _buildInput(
                  label: "Durasi (Hari)",
                  controller: createDayController,
                  icon: FontAwesomeIcons.calendarDay,
                  type: TextInputType.number,
                ),
                const Text(
                  "ROLE",
                  style: TextStyle(
                    color: _T.black,
                    fontSize: 11,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.5,
                  ),
                ),
                const SizedBox(height: 8),
                _roleDropdown(
                  newUserRole,
                  (val) =>
                      setState(() => newUserRole = val ?? 'member'),
                ),
                const SizedBox(height: 20),
                _yellowButton(
                  label: "CREATE ACCOUNT",
                  icon: Icons.person_add_alt_1_rounded,
                  onTap: isLoading ? null : _createAccount,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ─── MANAGE ───────────────────────────────────────────────
  Widget _manageSection() {
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(16, 20, 16, 110),
      physics: const BouncingScrollPhysics(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _sectionLabel(
              "EXTEND DURATION", FontAwesomeIcons.clockRotateLeft),
          const SizedBox(height: 14),
          _panel(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Row(
                  children: [
                    Expanded(
                      flex: 3,
                      child: _buildInput(
                        label: "Username",
                        controller: editUsernameController,
                        icon: FontAwesomeIcons.userPen,
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      flex: 2,
                      child: _buildInput(
                        label: "Hari",
                        controller: editDayController,
                        icon: FontAwesomeIcons.calendarPlus,
                        type: TextInputType.number,
                      ),
                    ),
                  ],
                ),
                _yellowButton(
                  label: "ADD DAYS",
                  icon: Icons.add_circle_outline_rounded,
                  onTap: isLoading ? null : _editUser,
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          Container(height: 2, color: _T.black),
          const SizedBox(height: 20),
          _sectionLabel("DELETE USER", FontAwesomeIcons.userSlash),
          const SizedBox(height: 14),
          _panel(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                _buildInput(
                  label: "Username Target",
                  controller: deleteController,
                  icon: FontAwesomeIcons.user,
                ),
                _yellowButton(
                  label: "DELETE ACCOUNT",
                  icon: Icons.delete_forever_rounded,
                  onTap: isLoading ? null : _deleteUser,
                  isError: true,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ─── BOTTOM NAV ───────────────────────────────────────────
  Widget _bottomSegmentNav() {
    final items = [
      _NavSeg(icon: Icons.dashboard_rounded, label: "Home"),
      _NavSeg(icon: FontAwesomeIcons.users, label: "Users"),
      _NavSeg(icon: Icons.person_add_alt_1_rounded, label: "Create"),
      _NavSeg(icon: Icons.tune_rounded, label: "Manage"),
    ];

    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
        child: Container(
          height: 68,
          decoration: BoxDecoration(
            color: _T.white,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _T.black, width: 3),
            boxShadow: _S.md,
          ),
          child: Row(
            children: List.generate(items.length, (i) {
              final active = _section == i;
              return _FloatingNavItem(
                icon: items[i].icon,
                label: items[i].label,
                isActive: active,
                onTap: () {
                  HapticFeedback.lightImpact();
                  setState(() => _section = i);
                },
              );
            }),
          ),
        ),
      ),
    );
  }

  Widget _buildCurrentSection() {
    switch (_section) {
      case 0:
        return _homeSection();
      case 1:
        return _usersSection();
      case 2:
        return _createSection();
      case 3:
        return _manageSection();
      default:
        return _homeSection();
    }
  }

  // ═══════════════════════════════════════════════════════════
  //  BUILD
  // ═══════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _T.bg,
      extendBody: true,
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            // ─── HEADER ─────────────────────────────────────
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: _T.yellow,
                      borderRadius: BorderRadius.circular(12),
                      border:
                          Border.all(color: _T.black, width: 2.5),
                      boxShadow: _S.sm,
                    ),
                    child: const Icon(Icons.shield_rounded,
                        color: _T.black, size: 20),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          "OWNER PANEL",
                          style: TextStyle(
                            color: _T.black,
                            fontSize: 16,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1.2,
                          ),
                        ),
                        Text(
                          "@${widget.username}",
                          style: const TextStyle(
                            color: _T.textMuted,
                            fontSize: 11,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ],
                    ),
                  ),
                  GestureDetector(
                    onTap: () {
                      HapticFeedback.lightImpact();
                      _fetchUsers();
                    },
                    child: Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: _T.yellow,
                        shape: BoxShape.circle,
                        border:
                            Border.all(color: _T.black, width: 2.5),
                        boxShadow: _S.sm,
                      ),
                      child: const Icon(Icons.refresh_rounded,
                          color: _T.black, size: 18),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(child: _buildCurrentSection()),
          ],
        ),
      ),
      bottomNavigationBar: _bottomSegmentNav(),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  NAV ITEM
// ═══════════════════════════════════════════════════════════════════
class _NavSeg {
  final IconData icon;
  final String label;
  const _NavSeg({required this.icon, required this.label});
}

class _FloatingNavItem extends StatefulWidget {
  final IconData icon;
  final String label;
  final bool isActive;
  final VoidCallback onTap;

  const _FloatingNavItem({
    required this.icon,
    required this.label,
    required this.isActive,
    required this.onTap,
  });

  @override
  State<_FloatingNavItem> createState() => _FloatingNavItemState();
}

class _FloatingNavItemState extends State<_FloatingNavItem> {
  bool _isPressed = false;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: GestureDetector(
        onTapDown: (_) => setState(() => _isPressed = true),
        onTapUp: (_) => setState(() => _isPressed = false),
        onTapCancel: () => setState(() => _isPressed = false),
        onTap: widget.onTap,
        child: AnimatedScale(
          duration: const Duration(milliseconds: 120),
          scale: _isPressed ? 0.94 : 1.0,
          child: Padding(
            padding:
                const EdgeInsets.symmetric(horizontal: 5, vertical: 7),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 250),
              curve: Curves.easeOutCubic,
              decoration: widget.isActive
                  ? BoxDecoration(
                      color: _T.yellow,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                          color: _T.black, width: 2.5),
                      boxShadow: _S.sm,
                    )
                  : BoxDecoration(
                      color: Colors.transparent,
                      borderRadius: BorderRadius.circular(12),
                    ),
              child: Padding(
                padding: const EdgeInsets.symmetric(
                    horizontal: 10, vertical: 8),
                child: Row(
                  mainAxisAlignment: widget.isActive
                      ? MainAxisAlignment.start
                      : MainAxisAlignment.center,
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    Icon(
                      widget.icon,
                      color: _T.black,
                      size: 18,
                    ),
                    if (widget.isActive) ...[
                      const SizedBox(width: 6),
                      Flexible(
                        child: Text(
                          widget.label,
                          style: const TextStyle(
                            color: _T.black,
                            fontSize: 11.5,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 0.3,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}